readme

To run:

file must be formatted correctly:

maoriWord, englishWord
maoriWord, englishWord
title, theTitle

eg. colours.txt

Mā,White
Whero,Red
Kārera,Light green
Māwhero,Pink
Kōwhai,Yellow
Kākāriki,Dark green
Māota,Dark green
Pango,Black
Parauri,Brown
Paraone,Brown
Kahurangi,Blue
Karaka,Orange
Title, COLOURS


Formatted documents are in app/resources 
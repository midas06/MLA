var MLA = MLA || {};

(function () {
    "use strict";
    var controller = new MLA.Controller();
    controller.init();
})();

// 4